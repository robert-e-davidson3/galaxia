Dear developer

 I hope you like these assets. If you need more assets like this you might be interested in my  site,  www.gamedeveloperstudio.com . I'm aiming to create a library  of high quality  assets all of which are  economically accessible  to all developers, There are even more free ones like this too.

If you like them or use them why not consider visiting or supporting the site, the more support the more assets I can produce.

Thanks 

Robert Brooks

www.gamedeveloperstudio.com
